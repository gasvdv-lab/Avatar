"""Future modular costume system."""
