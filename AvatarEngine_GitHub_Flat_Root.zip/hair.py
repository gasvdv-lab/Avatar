"""Future hair system."""
