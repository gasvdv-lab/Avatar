"""Future stylized material system."""
