"""Future humanoid rig system."""
